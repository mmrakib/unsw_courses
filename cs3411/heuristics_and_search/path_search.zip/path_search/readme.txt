#**********************************************************************
#   readme.txt
#
#   UNSW CSE
#   COMP3411/9814
#

You can use these commands to check your answers to the
Week 3 Tutorial Questions:

python3 search.py --env graph --s bfs --v --unique
python3 search.py --env graph --s bfs1 --v --unique
python3 search.py --env graph --s dfs --v --unique
python3 search.py --env graph --s ucs --v --unique
python3 search.py --env graph --s greedy --v --unique
python3 search.py --env graph --s astar --v --unique

python3 search.py --env sliding --start tutorial --s astar --v

python3 search.py --env romania --s bfs --v
python3 search.py --env romania --s bfs1 --v
python3 search.py --env romania --s ucs --start dobreta --goal fagaras --v --unique
python3 search.py --env romania --s dfs --start dobreta --goal zerind --v --unique

